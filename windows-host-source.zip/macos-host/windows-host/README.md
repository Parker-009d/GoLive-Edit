# GoLiv Edit Windows host

This is a Windows host port using WinForms/WebView2 for the existing mixer interface, NAudio/WASAPI for device input and Local Live WAV capture, and OBS WebSocket v5 for assigned source gain/mute controls.

## Build on Windows

Install the .NET 8 SDK and Microsoft Edge WebView2 Runtime, then run `build-windows.ps1`. The script creates a self-contained x64 single-file executable in `dist\win-x64`. The Edge WebView2 Runtime remains a prerequisite.

The current cross-compiled output was built from macOS targeting win-x64. It has not been run on a Windows PC. It is a beta port, not a Store release. Validate audio-device selection, recording, OBS authentication/assignments, and phone pairing on Windows first. Local Live currently records stereo input with fader/mute/solo gain control; GoLive DSP gate, EQ, compressor, and FX processing still need their Windows audio-path implementation. Do not use it for a live broadcast until that processing is ported and checked.

## Microsoft Store

The EXE is an app binary, not an installer. For Store submission, package it as MSIX (preferred), or build an offline signed EXE/MSI installer and submit its versioned download URL through Partner Center. The current output is unsigned and is for Windows testing/GitHub beta only.
