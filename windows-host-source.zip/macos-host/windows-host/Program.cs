using System.Collections.Concurrent;
using System.Net;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace GoLivEdit;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MixerWindow());
    }
}

internal sealed class MixerWindow : Form
{
    private readonly WebView2 web = new() { Dock = DockStyle.Fill };
    private readonly MMDeviceEnumerator enumerator = new();
    private readonly System.Windows.Forms.Timer stateTimer = new() { Interval = 50 };
    private readonly System.Windows.Forms.Timer meterTimer = new() { Interval = 33 };
    private readonly object audioLock = new();
    private readonly object recordLock = new();
    private MMDevice? selectedDevice;
    private WasapiCapture? capture;
    private WaveFileWriter? writer;
    private JsonElement mixerState;
    private string remoteState = "{\"ch\":[],\"main\":{}}";
    private readonly float[][] spectrumRing = Enumerable.Range(0, 4).Select(_ => new float[2048]).ToArray();
    private int spectrumIndex;
    private int spectrumFilled;
    private double[] levels = [-90, -90, -90, -90];
    private bool[] clips = [false, false, false, false];
    private DateTime[] clipUntil = [DateTime.MinValue, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue];
    private double sampleRate;
    private int channelCount;
    private string selectedUid = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "AudioDeviceUid", "") as string ?? "";
    private readonly ObsSocket obs = new();
    private string pairingCode = NewPairCode();
    private string obsSource1 = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource1", "") as string ?? "";
    private string obsSource2 = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource2", "") as string ?? "";
    private readonly HashSet<string> pairedTokens = new();
    private HttpListener? remote;
    private DateTime codeExpiry = DateTime.UtcNow.AddMinutes(3);
    private const int PairPort = 8443;

    public MixerWindow()
    {
        Text = "GoLiv Edit App";
        MinimumSize = new Size(980, 620);
        ClientSize = new Size(1420, 940);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.Black;
        Icon = new Icon(Path.Combine(AppContext.BaseDirectory, "Resources", "GoLive.ico"));
        Controls.Add(web);
        Shown += async (_, _) => await InitializeMixerAsync();
        FormClosing += (_, _) => { stateTimer.Stop(); meterTimer.Stop(); StopCapture(); StopRecording(); _ = obs.DisconnectAsync(); remote?.Close(); };
        stateTimer.Tick += async (_, _) => await PublishMixerStateAsync();
        meterTimer.Tick += async (_, _) => await PublishMetersAsync();
        obs.StatusChanged += (text, connected) => { if (!IsDisposed && IsHandleCreated) BeginInvoke(() => _ = SetObsStatusAsync(text, connected)); };
        obs.InputsReceived += names => { if (!IsDisposed && IsHandleCreated) BeginInvoke(() => _ = PublishObsInputsAsync(names)); };
    }

    private async Task InitializeMixerAsync()
    {
        var inputs = GetInputs();
        var persisted = inputs.FirstOrDefault(x => x.ID == selectedUid) ?? inputs.FirstOrDefault();
        selectedDevice = persisted;
        if (selectedDevice is not null) selectedUid = selectedDevice.ID;
        var config = new
        {
            code = pairingCode, ip = LanAddress(), url = $"http://{LanAddress()}:{PairPort}/",
            obsInputs = Array.Empty<string>(), obsSource1, obsSource2,
            audioInputs = inputs.Select(x => x.FriendlyName).ToArray(), audioInputIndex = Math.Max(0, inputs.IndexOf(selectedDevice!))
        };
        var configJson = JsonSerializer.Serialize(config);
        var bridge = $"window.__GO_LIVE_CONFIG__={configJson};window.webkit={{messageHandlers:new Proxy({{}},{{get:(_,name)=>({{postMessage:body=>window.chrome.webview.postMessage({{handler:String(name),body}})}})}})}};";
        await web.EnsureCoreWebView2Async();
        await web.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(bridge);
        web.CoreWebView2.WebMessageReceived += OnWebMessage;
        var page = Path.Combine(AppContext.BaseDirectory, "Resources", "golive-edit-mixer.html");
        web.Source = new Uri(page);
        StartRemoteServer();
        if (selectedDevice is not null) StartCapture(selectedDevice);
        stateTimer.Start(); meterTimer.Start();
    }

    private List<MMDevice> GetInputs() => enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active).ToList();

    private async void OnWebMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            using var document = JsonDocument.Parse(e.WebMessageAsJson);
            var root = document.RootElement;
            var handler = root.GetProperty("handler").GetString() ?? "";
            var body = root.GetProperty("body");
            switch (handler)
            {
                case "goLiveAudioDevice":
                    var index = body.GetInt32(); var inputs = GetInputs();
                    if (index >= 0 && index < inputs.Count) { selectedDevice = inputs[index]; selectedUid = selectedDevice.ID; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "AudioDeviceUid", selectedUid); StartCapture(selectedDevice); }
                    break;
                case "goLiveRecordingControl":
                    if (body.GetProperty("action").GetString() == "stop") StopRecording(); else BeginRecording();
                    break;
                case "goLiveConnectOBS":
                    if (body.TryGetProperty("disconnect", out var disconnect) && disconnect.GetBoolean()) await obs.DisconnectAsync();
                    else await obs.ConnectAsync(body.GetProperty("host").GetString() ?? "127.0.0.1", body.GetProperty("port").GetInt32(), body.GetProperty("password").GetString() ?? "");
                    break;
                case "goLiveAssignOBS":
                    var channel = body.GetProperty("channel").GetInt32(); var source = body.GetProperty("source").GetString() ?? "";
                    if (channel == 1) { obsSource1 = source; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource1", source); }
                    if (channel == 2) { obsSource2 = source; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource2", source); }
                    obs.Assign(channel, source);
                    break;
                case "goLiveOutputControl":
                    var action = body.GetProperty("action").GetString();
                    await obs.RequestAsync(action == "startStream" ? "StartStream" : action == "stopStream" ? "StopStream" : action == "startRecord" ? "StartRecord" : "StopRecord", new { });
                    break;
                case "goLiveRotatePairing":
                    RotatePairingCode(); break;
            }
        }
        catch (Exception ex) { await SetObsStatusAsync("Windows host error: " + ex.Message, false); }
    }

    private void StartCapture(MMDevice device)
    {
        StopCapture();
        try
        {
            capture = new WasapiCapture(device);
            sampleRate = capture.WaveFormat.SampleRate; channelCount = capture.WaveFormat.Channels;
            var activeCapture = capture;
            activeCapture.DataAvailable += (_, e) => CaptureAudio(e.Buffer, e.BytesRecorded, activeCapture.WaveFormat);
            activeCapture.RecordingStopped += (_, e) => { if (e.Exception is not null) _ = SetRecordingStatusAsync("Audio capture stopped: " + e.Exception.Message, false, ""); };
            capture.StartRecording();
        }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Audio input error: " + ex.Message, false, ""); }
    }

    private void StopCapture()
    {
        try { capture?.StopRecording(); } catch { }
        capture?.Dispose(); capture = null;
        lock (audioLock) { levels = [-90, -90, -90, -90]; clips = [false, false, false, false]; }
    }

    private void CaptureAudio(byte[] bytes, int length, WaveFormat? format)
    {
        if (format is null || length < format.BlockAlign) return;
        var frames = length / format.BlockAlign; var channels = format.Channels;
        var samples = new float[frames * channels]; var peak = new double[Math.Min(4, channels)]; var sum = new double[peak.Length];
        for (var frame = 0; frame < frames; frame++) for (var c = 0; c < channels; c++)
        {
            var offset = frame * format.BlockAlign + c * (format.BitsPerSample / 8);
            float v = format.Encoding == WaveFormatEncoding.IeeeFloat && format.BitsPerSample == 32 ? BitConverter.ToSingle(bytes, offset) : format.BitsPerSample switch
            {
                16 => BitConverter.ToInt16(bytes, offset) / 32768f,
                24 => Read24(bytes, offset) / 8388608f,
                32 => BitConverter.ToInt32(bytes, offset) / 2147483648f,
                _ => 0
            };
            samples[frame * channels + c] = v;
            if (c < peak.Length) { peak[c] = Math.Max(peak[c], Math.Abs(v)); sum[c] += v * v; }
        }
        JsonElement state; lock (audioLock) state = mixerState;
        var ch = state.ValueKind == JsonValueKind.Object && state.TryGetProperty("ch", out var cs) ? cs : default;
        var main = state.ValueKind == JsonValueKind.Object && state.TryGetProperty("main", out var ms) ? ms : default;
        var muted = new bool[2]; var anySolo = false;
        if (ch.ValueKind == JsonValueKind.Array) foreach (var c in ch.EnumerateArray()) anySolo |= c.TryGetProperty("solo", out var so) && so.GetBoolean();
        var masterMuted = main.ValueKind == JsonValueKind.Object && main.TryGetProperty("mute", out var mm) && mm.GetBoolean();
        var masterDb = main.ValueKind == JsonValueKind.Object && main.TryGetProperty("db", out var md) ? md.GetDouble() : 0;
        for (var i = 0; i < 2; i++)
        {
            var c = ch.ValueKind == JsonValueKind.Array && ch.GetArrayLength() > i ? ch[i] : default;
            muted[i] = masterMuted || c.ValueKind != JsonValueKind.Object || (c.TryGetProperty("mute", out var m) && m.GetBoolean()) || (anySolo && (!c.TryGetProperty("solo", out var s) || !s.GetBoolean()));
        }
        var gL = ChannelGain(ch, 0, masterDb); var gR = ChannelGain(ch, 1, masterDb);
        lock (audioLock)
        {
            levels = [-90, -90, -90, -90];
            for (var frame = 0; frame < frames; frame++)
            {
                for (var c = 0; c < Math.Min(4, channels); c++) spectrumRing[c][spectrumIndex] = samples[frame * channels + c];
                spectrumIndex = (spectrumIndex + 1) % 2048; spectrumFilled = Math.Min(2048, spectrumFilled + 1);
            }
            for (var c = 0; c < peak.Length; c++)
            {
                levels[c] = Math.Max(-90, Math.Max(20 * Math.Log10(Math.Max(1e-5, Math.Sqrt(sum[c] / frames))), 20 * Math.Log10(Math.Max(1e-5, peak[c])) - 6));
                if (peak[c] >= .999) clipUntil[c] = DateTime.UtcNow.AddSeconds(1.5);
                clips[c] = DateTime.UtcNow < clipUntil[c];
            }
        }
        lock (recordLock)
        {
            if (writer is null) return;
            var output = new byte[frames * 6]; var pos = 0;
            for (var frame = 0; frame < frames; frame++) for (var side = 0; side < 2; side++)
            {
                var sourceChannel = Math.Min(side, channels - 1); var value = muted[side] ? 0 : samples[frame * channels + sourceChannel] * (float)(side == 0 ? gL : gR);
                value = Math.Clamp(value, -.98f, .98f); var sample = (int)(value * 8388607f);
                output[pos++] = (byte)sample; output[pos++] = (byte)(sample >> 8); output[pos++] = (byte)(sample >> 16);
            }
            writer.Write(output, 0, output.Length);
        }
    }

    private static double ChannelGain(JsonElement channels, int index, double masterDb)
    {
        var db = 0d;
        if (channels.ValueKind == JsonValueKind.Array && channels.GetArrayLength() > index)
        {
            var channel = channels[index]; if (channel.TryGetProperty("db", out var f)) db += f.GetDouble(); if (channel.TryGetProperty("trim", out var t)) db += t.GetDouble();
        }
        return Math.Pow(10, Math.Clamp(db + masterDb, -60, 26) / 20);
    }

    private void BeginRecording()
    {
        if (capture is null) { _ = SetRecordingStatusAsync("Select an active audio input first.", false, ""); return; }
        using var dialog = new SaveFileDialog { Filter = "WAV audio|*.wav", FileName = $"GoLive-Recording-{DateTime.Now:yyyyMMdd-HHmmss}.wav" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var format = new WaveFormat(capture.WaveFormat.SampleRate, 24, 2);
            lock (recordLock) writer = new WaveFileWriter(dialog.FileName, format);
            _ = SetRecordingStatusAsync("Recording · " + Path.GetFileName(dialog.FileName), true, Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Could not start recording: " + ex.Message, false, ""); }
    }

    private void StopRecording()
    {
        lock (recordLock) { writer?.Dispose(); writer = null; }
        _ = SetRecordingStatusAsync("Recording saved", false, "");
    }

    private async Task PublishMixerStateAsync()
    {
        if (web.CoreWebView2 is null) return;
        try
        {
            var result = await web.CoreWebView2.ExecuteScriptAsync("window.__goLiveRemoteState ? window.__goLiveRemoteState() : null");
            if (result != "null")
            {
                var json = JsonSerializer.Deserialize<string>(result);
                if (json is not null)
                {
                    using var document = JsonDocument.Parse(json); var snapshot = document.RootElement.Clone();
                    lock (audioLock) { mixerState = snapshot; remoteState = snapshot.GetRawText(); }
                    await obs.SyncAsync(snapshot);
                }
            }
        }
        catch { }
    }

    private async Task PublishMetersAsync()
    {
        if (web.CoreWebView2 is null) return;
        double[] l; bool[] c; double sr; int ch; float[][] samples; int filled;
        lock (audioLock)
        {
            l = levels.ToArray(); c = clips.ToArray(); sr = sampleRate; ch = channelCount; filled = spectrumFilled;
            samples = spectrumRing.Select(r => Enumerable.Range(0, filled).Select(i => r[(spectrumIndex + 2048 - filled + i) % 2048]).ToArray()).ToArray();
        }
        var payload = JsonSerializer.Serialize(new { levels = l, spectra = CalculateSpectra(samples, filled, sr), info = new { sampleRate = sr, channels = ch, clips = c } });
        try { await web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveSetAudioLevels({payload})"); } catch { }
    }

    private static double[][] CalculateSpectra(float[][] samples, int filled, double rate)
    {
        var result = Enumerable.Range(0, 4).Select(_ => Enumerable.Repeat(-90d, 48).ToArray()).ToArray();
        if (filled < 2048 || rate <= 0) return result;
        var maxHz = Math.Min(20000, rate / 2.1);
        for (var ch = 0; ch < Math.Min(4, samples.Length); ch++) for (var band = 0; band < 48; band++)
        {
            var hz = 20 * Math.Pow(maxHz / 20, band / 47d); var coeff = 2 * Math.Cos(2 * Math.PI * hz / rate); double s1 = 0, s2 = 0;
            for (var i = 0; i < 2048; i++) { var window = .5 - .5 * Math.Cos(2 * Math.PI * i / 2047); var value = samples[ch][i] * window + coeff * s1 - s2; s2 = s1; s1 = value; }
            var power = Math.Max(0, s1 * s1 + s2 * s2 - coeff * s1 * s2); var magnitude = 4 * Math.Sqrt(power) / 2048;
            result[ch][band] = Math.Max(-90, 20 * Math.Log10(Math.Max(magnitude, 1e-5)));
        }
        return result;
    }
    private Task SetRecordingStatusAsync(string text, bool active, string file) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveRecordingStatus({JsonSerializer.Serialize(new { text, active, file })})");
    private Task SetObsStatusAsync(string text, bool connected) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveObsStatus({JsonSerializer.Serialize(new { text, connected })})");
    private Task PublishObsInputsAsync(string[] inputs) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveObsInputs({JsonSerializer.Serialize(new { inputs, source1 = obsSource1, source2 = obsSource2 })})");

    private void StartRemoteServer()
    {
        try { remote = new HttpListener(); remote.Prefixes.Add($"http://+:{PairPort}/"); remote.Start(); _ = Task.Run(RemoteLoopAsync); }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Phone remote could not start: " + ex.Message, false, ""); }
    }
    private async Task RemoteLoopAsync()
    {
        while (remote?.IsListening == true)
        {
            HttpListenerContext c; try { c = await remote.GetContextAsync(); } catch { break; }
            _ = Task.Run(() => HandleRemoteAsync(c));
        }
    }
    private async Task HandleRemoteAsync(HttpListenerContext c)
    {
        try
        {
            var path = c.Request.Url?.AbsolutePath ?? "/"; var token = c.Request.Headers["Authorization"]?.Replace("Bearer ", "") ?? "";
            object response; int status = 200;
            if (path == "/" && c.Request.HttpMethod == "GET") { var page = await File.ReadAllBytesAsync(Path.Combine(AppContext.BaseDirectory, "Resources", "phone-remote.html")); c.Response.ContentType = "text/html; charset=utf-8"; c.Response.ContentLength64 = page.Length; await c.Response.OutputStream.WriteAsync(page); c.Response.Close(); return; }
            if (path == "/api/pair" && c.Request.HttpMethod == "POST")
            {
                using var doc = await JsonDocument.ParseAsync(c.Request.InputStream); var code = doc.RootElement.GetProperty("code").GetString() ?? "";
                if (DateTime.UtcNow < codeExpiry && code.Equals(pairingCode, StringComparison.OrdinalIgnoreCase)) { var t = Guid.NewGuid().ToString("N"); lock (pairedTokens) pairedTokens.Add(t); response = new { ok = true, token = t }; }
                else { status = 401; response = new { ok = false, error = "Pairing code is invalid or expired" }; }
            }
            else if (path == "/api/state" && IsPaired(token))
            {
                string snapshot; lock (audioLock) snapshot = remoteState;
                var snapshotBytes = Encoding.UTF8.GetBytes(snapshot); c.Response.ContentType = "application/json; charset=utf-8"; c.Response.ContentLength64 = snapshotBytes.Length; await c.Response.OutputStream.WriteAsync(snapshotBytes); c.Response.Close(); return;
            }
            else if (path == "/api/control" && c.Request.HttpMethod == "POST" && IsPaired(token))
            {
                using var command = await JsonDocument.ParseAsync(c.Request.InputStream);
                var json = command.RootElement.GetRawText();
                await web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveSetRemoteControl && window.__goLiveSetRemoteControl({json})");
                response = new { ok = true };
            }
            else { status = 401; response = new { ok = false, error = "Pair this phone again" }; }
            var bytes = JsonSerializer.SerializeToUtf8Bytes(response); c.Response.StatusCode = status; c.Response.ContentType = "application/json; charset=utf-8"; c.Response.ContentLength64 = bytes.Length; await c.Response.OutputStream.WriteAsync(bytes); c.Response.Close();
        }
        catch { try { c.Response.StatusCode = 500; c.Response.Close(); } catch { } }
    }
    private bool IsPaired(string token) { lock (pairedTokens) return pairedTokens.Contains(token); }
    private void RotatePairingCode()
    {
        pairingCode = NewPairCode(); codeExpiry = DateTime.UtcNow.AddMinutes(3);
        _ = web.CoreWebView2.ExecuteScriptAsync($"window.__goLivePairingUpdated && window.__goLivePairingUpdated({JsonSerializer.Serialize(new { code = pairingCode, url = $"http://{LanAddress()}:{PairPort}/", ip = LanAddress() })})");
    }
    private static string NewPairCode() => new string(Enumerable.Range(0, 8).Select(_ => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Random.Shared.Next(32)]).ToArray());
    private static string LanAddress() => System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList.FirstOrDefault(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !System.Net.IPAddress.IsLoopback(x))?.ToString() ?? "127.0.0.1";
    private static int Read24(byte[] bytes, int offset) { var v = bytes[offset] | bytes[offset+1] << 8 | bytes[offset+2] << 16; if ((v & 0x800000) != 0) v |= unchecked((int)0xff000000); return v; }
}

internal sealed class ObsSocket
{
    private ClientWebSocket? socket;
    private readonly SemaphoreSlim sendLock = new(1,1);
    private readonly Dictionary<int,string> assigned = new();
    private readonly Dictionary<string,string> lastValues = new();
    private string host = "127.0.0.1"; private int port = 4455; private bool connected;
    public event Action<string,bool>? StatusChanged;
    public event Action<string[]>? InputsReceived;
    public async Task ConnectAsync(string h,int p,string password)
    {
        await DisconnectAsync(); host=h;port=p;StatusChanged?.Invoke("Connecting to OBS…",false); socket=new ClientWebSocket(); await socket.ConnectAsync(new Uri($"ws://{host}:{port}"),CancellationToken.None);
        var buffer=new byte[65536]; var r=await socket.ReceiveAsync(buffer,CancellationToken.None); using var hello=JsonDocument.Parse(buffer.AsMemory(0,r.Count));
        var d=hello.RootElement.GetProperty("d"); var identify=new Dictionary<string,object>{{"rpcVersion",1}};
        if(d.TryGetProperty("authentication",out var auth)){var salt=auth.GetProperty("salt").GetString()!;var challenge=auth.GetProperty("challenge").GetString()!;var secret=Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(password+salt)));identify["authentication"]=Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(secret+challenge)));}
        await SendAsync(new {op=1,d=identify}); r=await socket.ReceiveAsync(buffer,CancellationToken.None); using var identified=JsonDocument.Parse(buffer.AsMemory(0,r.Count)); connected=identified.RootElement.GetProperty("op").GetInt32()==2;
        if (!connected) { StatusChanged?.Invoke("OBS rejected the password or connection.",false); await DisconnectAsync(); return; }
        lastValues.Clear(); StatusChanged?.Invoke("Connected to OBS",true); _=Task.Run(ReceiveLoopAsync); await RequestAsync("GetInputList",new { });
    }
    public async Task DisconnectAsync(){connected=false;if(socket is not null){try{socket.Abort();socket.Dispose();}catch{}}socket=null;lastValues.Clear();StatusChanged?.Invoke("Not connected",false);await Task.CompletedTask;}
    public void Assign(int channel,string source){assigned[channel]=source;}
    public async Task SyncAsync(JsonElement state)
    {
        if(!connected)return;
        if(state.TryGetProperty("ch",out var channels)&&state.TryGetProperty("main",out var main))
        {
            var muted=main.GetProperty("mute").GetBoolean();var master=main.GetProperty("db").GetDouble();var solo=channels.EnumerateArray().Any(x=>x.GetProperty("solo").GetBoolean());var n=0;
            foreach(var c in channels.EnumerateArray())
            {
                n++; if(!assigned.TryGetValue(n,out var name)||name.Length==0)continue;
                var db=c.GetProperty("db").GetDouble()+master+(c.TryGetProperty("trim",out var tr)?tr.GetDouble():0);
                var m=muted||c.GetProperty("mute").GetBoolean()||(solo&&!c.GetProperty("solo").GetBoolean());
                var value=$"{Math.Clamp(db,-100,26):F2}|{m}";
                if(lastValues.GetValueOrDefault(name)==value)continue;
                lastValues[name]=value;
                await RequestAsync("SetInputVolume",new {inputName=name,inputVolumeDb=Math.Clamp(db,-100,26)});
                await RequestAsync("SetInputMute",new {inputName=name,inputMuted=m});
            }
        }
    }
    public Task RequestAsync(string type,object data)=>SendAsync(new {op=6,d=new {requestType=type,requestId=Guid.NewGuid().ToString("N"),requestData=data}});
    private async Task SendAsync(object value){if(socket is null)return;var bytes=JsonSerializer.SerializeToUtf8Bytes(value);await sendLock.WaitAsync();try{await socket.SendAsync(bytes,WebSocketMessageType.Text,true,CancellationToken.None);}finally{sendLock.Release();}}
    private async Task ReceiveLoopAsync()
    {
        var b=new byte[65536];
        while(socket?.State==WebSocketState.Open)
        {
            try
            {
                var r=await socket.ReceiveAsync(b,CancellationToken.None); if(r.MessageType==WebSocketMessageType.Close)break;
                using var d=JsonDocument.Parse(b.AsMemory(0,r.Count)); var root=d.RootElement;
                if(root.GetProperty("op").GetInt32()==7)
                {
                    var e=root.GetProperty("d"); var request=e.GetProperty("requestType").GetString();
                    if(e.TryGetProperty("requestStatus",out var rs)&&rs.TryGetProperty("result",out var ok)&&!ok.GetBoolean()) StatusChanged?.Invoke("OBS error: "+(rs.TryGetProperty("comment",out var comment)?comment.GetString():"request failed"),true);
                    if(request=="GetInputList"&&e.TryGetProperty("responseData",out var data))
                    {
                        var names=data.GetProperty("inputs").EnumerateArray().Select(x=>x.GetProperty("inputName").GetString()??"").Where(x=>x.Length>0).OrderBy(x=>x).ToArray();
                        InputsReceived?.Invoke(names);
                    }
                }
            }
            catch(Exception ex){connected=false;StatusChanged?.Invoke("OBS connection failed: "+ex.Message,false);break;}
        }
        if(connected){connected=false;StatusChanged?.Invoke("OBS disconnected",false);}
    }
}
