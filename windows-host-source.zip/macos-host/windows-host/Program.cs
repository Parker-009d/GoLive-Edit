using System.Collections.Concurrent;
using System.Net;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace GoLivEdit;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MixerWindow());
    }
}

internal sealed class MixerWindow : Form
{
    private readonly WebView2 web = new() { Dock = DockStyle.Fill };
    private readonly MMDeviceEnumerator enumerator = new();
    private readonly System.Windows.Forms.Timer stateTimer = new() { Interval = 50 };
    private readonly System.Windows.Forms.Timer meterTimer = new() { Interval = 33 };
    private readonly object audioLock = new();
    private readonly object recordLock = new();
    private readonly LocalDSP[] localDSP = [new(), new()];
    private readonly LocalFX localFX = new();
    private MMDevice? selectedDevice;
    private WasapiCapture? capture;
    private WaveFileWriter? writer;
    private JsonElement mixerState;
    private string remoteState = "{\"ch\":[],\"main\":{}}";
    private readonly float[][] spectrumRing = Enumerable.Range(0, 4).Select(_ => new float[2048]).ToArray();
    private int spectrumIndex;
    private int spectrumFilled;
    private double[] levels = [-90, -90, -90, -90];
    private bool[] clips = [false, false, false, false];
    private DateTime[] clipUntil = [DateTime.MinValue, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue];
    private double sampleRate;
    private int channelCount;
    private string selectedUid = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "AudioDeviceUid", "") as string ?? "";
    private readonly ObsSocket obs = new();
    private string pairingCode = NewPairCode();
    private string obsSource1 = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource1", "") as string ?? "";
    private string obsSource2 = Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource2", "") as string ?? "";
    private readonly HashSet<string> pairedTokens = new();
    private HttpListener? remote;
    private DateTime codeExpiry = DateTime.UtcNow.AddMinutes(3);
    private const int PairPort = 8443;

    public MixerWindow()
    {
        Text = "GoLiv Edit App";
        MinimumSize = new Size(980, 620);
        ClientSize = new Size(1420, 940);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.Black;
        Icon = new Icon(Path.Combine(AppContext.BaseDirectory, "Resources", "GoLive.ico"));
        Controls.Add(web);
        Shown += async (_, _) => await InitializeMixerAsync();
        FormClosing += (_, _) => { stateTimer.Stop(); meterTimer.Stop(); StopCapture(); StopRecording(); _ = obs.DisconnectAsync(); remote?.Close(); };
        stateTimer.Tick += async (_, _) => await PublishMixerStateAsync();
        meterTimer.Tick += async (_, _) => await PublishMetersAsync();
        obs.StatusChanged += (text, connected) => { if (!IsDisposed && IsHandleCreated) BeginInvoke(() => _ = SetObsStatusAsync(text, connected)); };
        obs.InputsReceived += names => { if (!IsDisposed && IsHandleCreated) BeginInvoke(() => _ = PublishObsInputsAsync(names)); };
    }

    private async Task InitializeMixerAsync()
    {
        var inputs = GetInputs();
        var persisted = inputs.FirstOrDefault(x => x.ID == selectedUid) ?? inputs.FirstOrDefault();
        selectedDevice = persisted;
        if (selectedDevice is not null) selectedUid = selectedDevice.ID;
        var config = new
        {
            code = pairingCode, ip = LanAddress(), url = $"http://{LanAddress()}:{PairPort}/",
            obsInputs = Array.Empty<string>(), obsSource1, obsSource2,
            audioInputs = inputs.Select(x => x.FriendlyName).ToArray(), audioInputIndex = Math.Max(0, inputs.IndexOf(selectedDevice!))
        };
        var configJson = JsonSerializer.Serialize(config);
        var bridge = $"window.__GO_LIVE_CONFIG__={configJson};window.webkit={{messageHandlers:new Proxy({{}},{{get:(_,name)=>({{postMessage:body=>window.chrome.webview.postMessage({{handler:String(name),body}})}})}})}};";
        await web.EnsureCoreWebView2Async();
        await web.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(bridge);
        web.CoreWebView2.WebMessageReceived += OnWebMessage;
        var page = Path.Combine(AppContext.BaseDirectory, "Resources", "golive-edit-mixer.html");
        web.Source = new Uri(page);
        StartRemoteServer();
        if (selectedDevice is not null) StartCapture(selectedDevice);
        stateTimer.Start(); meterTimer.Start();
    }

    private List<MMDevice> GetInputs() => enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active).ToList();

    private async void OnWebMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            using var document = JsonDocument.Parse(e.WebMessageAsJson);
            var root = document.RootElement;
            var handler = root.GetProperty("handler").GetString() ?? "";
            var body = root.GetProperty("body");
            switch (handler)
            {
                case "goLiveAudioDevice":
                    var index = body.GetInt32(); var inputs = GetInputs();
                    if (index >= 0 && index < inputs.Count) { selectedDevice = inputs[index]; selectedUid = selectedDevice.ID; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "AudioDeviceUid", selectedUid); StartCapture(selectedDevice); }
                    break;
                case "goLiveRecordingControl":
                    if (body.GetProperty("action").GetString() == "stop") StopRecording(); else BeginRecording();
                    break;
                case "goLiveConnectOBS":
                    if (body.TryGetProperty("disconnect", out var disconnect) && disconnect.GetBoolean()) await obs.DisconnectAsync();
                    else await obs.ConnectAsync(body.GetProperty("host").GetString() ?? "127.0.0.1", body.GetProperty("port").GetInt32(), body.GetProperty("password").GetString() ?? "");
                    break;
                case "goLiveAssignOBS":
                    var channel = body.GetProperty("channel").GetInt32(); var source = body.GetProperty("source").GetString() ?? "";
                    if (channel == 1) { obsSource1 = source; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource1", source); }
                    if (channel == 2) { obsSource2 = source; Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\GoLiveEdit", "ObsSource2", source); }
                    obs.Assign(channel, source);
                    break;
                case "goLiveOutputControl":
                    var action = body.GetProperty("action").GetString();
                    await obs.RequestAsync(action == "startStream" ? "StartStream" : action == "stopStream" ? "StopStream" : action == "startRecord" ? "StartRecord" : "StopRecord", new { });
                    break;
                case "goLiveRotatePairing":
                    RotatePairingCode(); break;
            }
        }
        catch (Exception ex) { await SetObsStatusAsync("Windows host error: " + ex.Message, false); }
    }

    private void StartCapture(MMDevice device)
    {
        StopCapture();
        try
        {
            capture = new WasapiCapture(device);
            sampleRate = capture.WaveFormat.SampleRate; channelCount = capture.WaveFormat.Channels;
            var activeCapture = capture;
            activeCapture.DataAvailable += (_, e) => CaptureAudio(e.Buffer, e.BytesRecorded, activeCapture.WaveFormat);
            activeCapture.RecordingStopped += (_, e) => { if (e.Exception is not null) _ = SetRecordingStatusAsync("Audio capture stopped: " + e.Exception.Message, false, ""); };
            capture.StartRecording();
        }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Audio input error: " + ex.Message, false, ""); }
    }

    private void StopCapture()
    {
        try { capture?.StopRecording(); } catch { }
        capture?.Dispose(); capture = null;
        lock (audioLock) { levels = [-90, -90, -90, -90]; clips = [false, false, false, false]; }
    }

    private void CaptureAudio(byte[] bytes, int length, WaveFormat? format)
    {
        if (format is null || length < format.BlockAlign) return;
        var frames = length / format.BlockAlign; var channels = format.Channels;
        var samples = new float[frames * channels]; var peak = new double[Math.Min(4, channels)]; var sum = new double[peak.Length];
        for (var frame = 0; frame < frames; frame++) for (var c = 0; c < channels; c++)
        {
            var offset = frame * format.BlockAlign + c * (format.BitsPerSample / 8);
            float v = format.Encoding == WaveFormatEncoding.IeeeFloat && format.BitsPerSample == 32 ? BitConverter.ToSingle(bytes, offset) : format.BitsPerSample switch
            {
                16 => BitConverter.ToInt16(bytes, offset) / 32768f,
                24 => Read24(bytes, offset) / 8388608f,
                32 => BitConverter.ToInt32(bytes, offset) / 2147483648f,
                _ => 0
            };
            samples[frame * channels + c] = v;
            if (c < peak.Length) { peak[c] = Math.Max(peak[c], Math.Abs(v)); sum[c] += v * v; }
        }
        JsonElement state; lock (audioLock) state = mixerState;
        var ch = state.ValueKind == JsonValueKind.Object && state.TryGetProperty("ch", out var cs) ? cs : default;
        var main = state.ValueKind == JsonValueKind.Object && state.TryGetProperty("main", out var ms) ? ms : default;
        localFX.Configure(state);
        var muted = new bool[2]; var anySolo = false;
        if (ch.ValueKind == JsonValueKind.Array) foreach (var c in ch.EnumerateArray()) anySolo |= c.TryGetProperty("solo", out var so) && so.GetBoolean();
        var masterMuted = main.ValueKind == JsonValueKind.Object && main.TryGetProperty("mute", out var mm) && mm.GetBoolean();
        var masterDb = main.ValueKind == JsonValueKind.Object && main.TryGetProperty("db", out var md) ? md.GetDouble() : 0;
        for (var i = 0; i < 2; i++)
        {
            var c = ch.ValueKind == JsonValueKind.Array && ch.GetArrayLength() > i ? ch[i] : default;
            muted[i] = masterMuted || c.ValueKind != JsonValueKind.Object || (c.TryGetProperty("mute", out var m) && m.GetBoolean()) || (anySolo && (!c.TryGetProperty("solo", out var s) || !s.GetBoolean()));
        }
        var gL = ChannelGain(ch, 0, masterDb); var gR = ChannelGain(ch, 1, masterDb);
        for (var i = 0; i < 2; i++)
            if (ch.ValueKind == JsonValueKind.Array && ch.GetArrayLength() > i && ch[i].TryGetProperty("dsp", out var dsp)) localDSP[i].Configure(dsp);
        lock (audioLock)
        {
            levels = [-90, -90, -90, -90];
            for (var frame = 0; frame < frames; frame++)
            {
                for (var c = 0; c < Math.Min(4, channels); c++) spectrumRing[c][spectrumIndex] = samples[frame * channels + c];
                spectrumIndex = (spectrumIndex + 1) % 2048; spectrumFilled = Math.Min(2048, spectrumFilled + 1);
            }
            for (var c = 0; c < peak.Length; c++)
            {
                levels[c] = Math.Max(-90, Math.Max(20 * Math.Log10(Math.Max(1e-5, Math.Sqrt(sum[c] / frames))), 20 * Math.Log10(Math.Max(1e-5, peak[c])) - 6));
                if (peak[c] >= .999) clipUntil[c] = DateTime.UtcNow.AddSeconds(1.5);
                clips[c] = DateTime.UtcNow < clipUntil[c];
            }
        }
        lock (recordLock)
        {
            if (writer is null) return;
            var output = new byte[frames * 6]; var pos = 0;
            for (var frame = 0; frame < frames; frame++)
            {
                var inL = muted[0] ? 0 : samples[frame * channels];
                var inR = muted[1] ? 0 : samples[frame * channels + Math.Min(1, channels - 1)];
                var left = muted[0] ? 0 : localDSP[0].Process(inL, format.SampleRate);
                var right = muted[1] ? 0 : localDSP[1].Process(inR, format.SampleRate);
                localFX.ProcessFrame(ref left, ref right, muted[0], muted[1], format.SampleRate);
                left = muted[0] ? 0 : left * (float)gL;
                right = muted[1] ? 0 : right * (float)gR;
                foreach (var valueIn in new[] { left, right })
                {
                    var value = SoftLimit(valueIn); var sample = (int)(value * 8388607f);
                    output[pos++] = (byte)sample; output[pos++] = (byte)(sample >> 8); output[pos++] = (byte)(sample >> 16);
                }
            }
            writer.Write(output, 0, output.Length);
        }
    }

    private static double ChannelGain(JsonElement channels, int index, double masterDb)
    {
        var db = 0d;
        if (channels.ValueKind == JsonValueKind.Array && channels.GetArrayLength() > index)
        {
            var channel = channels[index]; if (channel.TryGetProperty("db", out var f)) db += f.GetDouble(); if (channel.TryGetProperty("trim", out var t)) db += t.GetDouble();
        }
        return Math.Pow(10, Math.Clamp(db + masterDb, -60, 26) / 20);
    }

    private static float SoftLimit(float value)
    {
        var magnitude=Math.Abs(value); if(magnitude<=.85f)return value;
        var limited=.85f+.15f*MathF.Tanh((magnitude-.85f)/.15f);
        return value<0?-limited:limited;
    }

    private void BeginRecording()
    {
        if (capture is null) { _ = SetRecordingStatusAsync("Select an active audio input first.", false, ""); return; }
        using var dialog = new SaveFileDialog { Filter = "WAV audio|*.wav", FileName = $"GoLive-Recording-{DateTime.Now:yyyyMMdd-HHmmss}.wav" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var format = new WaveFormat(capture.WaveFormat.SampleRate, 24, 2);
            lock (recordLock) writer = new WaveFileWriter(dialog.FileName, format);
            _ = SetRecordingStatusAsync("Recording · " + Path.GetFileName(dialog.FileName), true, Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Could not start recording: " + ex.Message, false, ""); }
    }

    private void StopRecording()
    {
        lock (recordLock) { writer?.Dispose(); writer = null; }
        _ = SetRecordingStatusAsync("Recording saved", false, "");
    }

    private async Task PublishMixerStateAsync()
    {
        if (web.CoreWebView2 is null) return;
        try
        {
            var result = await web.CoreWebView2.ExecuteScriptAsync("window.__goLiveRemoteState ? window.__goLiveRemoteState() : null");
            if (result != "null")
            {
                var json = JsonSerializer.Deserialize<string>(result);
                if (json is not null)
                {
                    using var document = JsonDocument.Parse(json); var snapshot = document.RootElement.Clone();
                    lock (audioLock) { mixerState = snapshot; remoteState = snapshot.GetRawText(); }
                    await obs.SyncAsync(snapshot);
                }
            }
        }
        catch { }
    }

    private async Task PublishMetersAsync()
    {
        if (web.CoreWebView2 is null) return;
        double[] l; bool[] c; double sr; int ch; float[][] samples; int filled;
        lock (audioLock)
        {
            l = levels.ToArray(); c = clips.ToArray(); sr = sampleRate; ch = channelCount; filled = spectrumFilled;
            samples = spectrumRing.Select(r => Enumerable.Range(0, filled).Select(i => r[(spectrumIndex + 2048 - filled + i) % 2048]).ToArray()).ToArray();
        }
        var payload = JsonSerializer.Serialize(new { levels = l, spectra = CalculateSpectra(samples, filled, sr), info = new { sampleRate = sr, channels = ch, clips = c } });
        try { await web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveSetAudioLevels({payload})"); } catch { }
    }

    private static double[][] CalculateSpectra(float[][] samples, int filled, double rate)
    {
        var result = Enumerable.Range(0, 4).Select(_ => Enumerable.Repeat(-90d, 48).ToArray()).ToArray();
        if (filled < 2048 || rate <= 0) return result;
        var maxHz = Math.Min(20000, rate / 2.1);
        for (var ch = 0; ch < Math.Min(4, samples.Length); ch++) for (var band = 0; band < 48; band++)
        {
            var hz = 20 * Math.Pow(maxHz / 20, band / 47d); var coeff = 2 * Math.Cos(2 * Math.PI * hz / rate); double s1 = 0, s2 = 0;
            for (var i = 0; i < 2048; i++) { var window = .5 - .5 * Math.Cos(2 * Math.PI * i / 2047); var value = samples[ch][i] * window + coeff * s1 - s2; s2 = s1; s1 = value; }
            var power = Math.Max(0, s1 * s1 + s2 * s2 - coeff * s1 * s2); var magnitude = 4 * Math.Sqrt(power) / 2048;
            result[ch][band] = Math.Max(-90, 20 * Math.Log10(Math.Max(magnitude, 1e-5)));
        }
        return result;
    }
    private Task SetRecordingStatusAsync(string text, bool active, string file) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveRecordingStatus({JsonSerializer.Serialize(new { text, active, file })})");
    private Task SetObsStatusAsync(string text, bool connected) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveObsStatus({JsonSerializer.Serialize(new { text, connected })})");
    private Task PublishObsInputsAsync(string[] inputs) => web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveObsInputs({JsonSerializer.Serialize(new { inputs, source1 = obsSource1, source2 = obsSource2 })})");

    private void StartRemoteServer()
    {
        try { remote = new HttpListener(); remote.Prefixes.Add($"http://+:{PairPort}/"); remote.Start(); _ = Task.Run(RemoteLoopAsync); }
        catch (Exception ex) { _ = SetRecordingStatusAsync("Phone remote could not start: " + ex.Message, false, ""); }
    }
    private async Task RemoteLoopAsync()
    {
        while (remote?.IsListening == true)
        {
            HttpListenerContext c; try { c = await remote.GetContextAsync(); } catch { break; }
            _ = Task.Run(() => HandleRemoteAsync(c));
        }
    }
    private async Task HandleRemoteAsync(HttpListenerContext c)
    {
        try
        {
            var path = c.Request.Url?.AbsolutePath ?? "/"; var token = c.Request.Headers["Authorization"]?.Replace("Bearer ", "") ?? "";
            object response; int status = 200;
            if (path == "/" && c.Request.HttpMethod == "GET") { var page = await File.ReadAllBytesAsync(Path.Combine(AppContext.BaseDirectory, "Resources", "phone-remote.html")); c.Response.ContentType = "text/html; charset=utf-8"; c.Response.ContentLength64 = page.Length; await c.Response.OutputStream.WriteAsync(page); c.Response.Close(); return; }
            if (path == "/api/pair" && c.Request.HttpMethod == "POST")
            {
                using var doc = await JsonDocument.ParseAsync(c.Request.InputStream); var code = doc.RootElement.GetProperty("code").GetString() ?? "";
                if (DateTime.UtcNow < codeExpiry && code.Equals(pairingCode, StringComparison.OrdinalIgnoreCase)) { var t = Guid.NewGuid().ToString("N"); lock (pairedTokens) pairedTokens.Add(t); response = new { ok = true, token = t }; }
                else { status = 401; response = new { ok = false, error = "Pairing code is invalid or expired" }; }
            }
            else if (path == "/api/state" && IsPaired(token))
            {
                string snapshot; lock (audioLock) snapshot = remoteState;
                var snapshotBytes = Encoding.UTF8.GetBytes(snapshot); c.Response.ContentType = "application/json; charset=utf-8"; c.Response.ContentLength64 = snapshotBytes.Length; await c.Response.OutputStream.WriteAsync(snapshotBytes); c.Response.Close(); return;
            }
            else if (path == "/api/control" && c.Request.HttpMethod == "POST" && IsPaired(token))
            {
                using var command = await JsonDocument.ParseAsync(c.Request.InputStream);
                var json = command.RootElement.GetRawText();
                await web.CoreWebView2.ExecuteScriptAsync($"window.__goLiveSetRemoteControl && window.__goLiveSetRemoteControl({json})");
                response = new { ok = true };
            }
            else { status = 401; response = new { ok = false, error = "Pair this phone again" }; }
            var bytes = JsonSerializer.SerializeToUtf8Bytes(response); c.Response.StatusCode = status; c.Response.ContentType = "application/json; charset=utf-8"; c.Response.ContentLength64 = bytes.Length; await c.Response.OutputStream.WriteAsync(bytes); c.Response.Close();
        }
        catch { try { c.Response.StatusCode = 500; c.Response.Close(); } catch { } }
    }
    private bool IsPaired(string token) { lock (pairedTokens) return pairedTokens.Contains(token); }
    private void RotatePairingCode()
    {
        pairingCode = NewPairCode(); codeExpiry = DateTime.UtcNow.AddMinutes(3);
        _ = web.CoreWebView2.ExecuteScriptAsync($"window.__goLivePairingUpdated && window.__goLivePairingUpdated({JsonSerializer.Serialize(new { code = pairingCode, url = $"http://{LanAddress()}:{PairPort}/", ip = LanAddress() })})");
    }
    private static string NewPairCode() => new string(Enumerable.Range(0, 8).Select(_ => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Random.Shared.Next(32)]).ToArray());
    private static string LanAddress() => System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList.FirstOrDefault(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !System.Net.IPAddress.IsLoopback(x))?.ToString() ?? "127.0.0.1";
    private static int Read24(byte[] bytes, int offset) { var v = bytes[offset] | bytes[offset+1] << 8 | bytes[offset+2] << 16; if ((v & 0x800000) != 0) v |= unchecked((int)0xff000000); return v; }
}

internal sealed class ObsSocket
{
    private ClientWebSocket? socket;
    private readonly SemaphoreSlim sendLock = new(1,1);
    private readonly Dictionary<int,string> assigned = new();
    private readonly Dictionary<string,string> lastValues = new();
    private readonly Dictionary<string,string> pendingFilters = new();
    private readonly HashSet<string> requestedFilters = new();
    private readonly Dictionary<string,HashSet<string>> knownFilters = new();
    private readonly Dictionary<string,string> lastFilterValues = new();
    private string host = "127.0.0.1"; private int port = 4455; private bool connected;
    public event Action<string,bool>? StatusChanged;
    public event Action<string[]>? InputsReceived;
    public async Task ConnectAsync(string h,int p,string password)
    {
        await DisconnectAsync(); host=h;port=p;StatusChanged?.Invoke("Connecting to OBS…",false); socket=new ClientWebSocket(); await socket.ConnectAsync(new Uri($"ws://{host}:{port}"),CancellationToken.None);
        var buffer=new byte[65536]; var r=await socket.ReceiveAsync(buffer,CancellationToken.None); using var hello=JsonDocument.Parse(buffer.AsMemory(0,r.Count));
        var d=hello.RootElement.GetProperty("d"); var identify=new Dictionary<string,object>{{"rpcVersion",1}};
        if(d.TryGetProperty("authentication",out var auth)){var salt=auth.GetProperty("salt").GetString()!;var challenge=auth.GetProperty("challenge").GetString()!;var secret=Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(password+salt)));identify["authentication"]=Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(secret+challenge)));}
        await SendAsync(new {op=1,d=identify}); r=await socket.ReceiveAsync(buffer,CancellationToken.None); using var identified=JsonDocument.Parse(buffer.AsMemory(0,r.Count)); connected=identified.RootElement.GetProperty("op").GetInt32()==2;
        if (!connected) { StatusChanged?.Invoke("OBS rejected the password or connection.",false); await DisconnectAsync(); return; }
        lastValues.Clear(); lastFilterValues.Clear(); requestedFilters.Clear(); knownFilters.Clear(); pendingFilters.Clear();
        StatusChanged?.Invoke("Connected to OBS",true); _=Task.Run(ReceiveLoopAsync); await RequestAsync("GetInputList",new { });
    }
    public async Task DisconnectAsync(){connected=false;if(socket is not null){try{socket.Abort();socket.Dispose();}catch{}}socket=null;lastValues.Clear();lastFilterValues.Clear();requestedFilters.Clear();knownFilters.Clear();pendingFilters.Clear();StatusChanged?.Invoke("Not connected",false);await Task.CompletedTask;}
    public void Assign(int channel,string source){assigned[channel]=source;if(connected&&!string.IsNullOrWhiteSpace(source))_ = RequestFiltersAsync(source);}
    public async Task SyncAsync(JsonElement state)
    {
        if(!connected)return;
        if(state.TryGetProperty("ch",out var channels)&&state.TryGetProperty("main",out var main))
        {
            var muted=main.GetProperty("mute").GetBoolean();var master=main.GetProperty("db").GetDouble();var solo=channels.EnumerateArray().Any(x=>x.GetProperty("solo").GetBoolean());var n=0;
            foreach(var c in channels.EnumerateArray())
            {
                n++; if(!assigned.TryGetValue(n,out var name)||name.Length==0)continue;
                var db=c.GetProperty("db").GetDouble()+master+(c.TryGetProperty("trim",out var tr)?tr.GetDouble():0);
                var m=muted||c.GetProperty("mute").GetBoolean()||(solo&&!c.GetProperty("solo").GetBoolean());
                var value=$"{Math.Clamp(db,-100,26):F2}|{m}";
                if(lastValues.GetValueOrDefault(name)!=value)
                {
                    lastValues[name]=value;
                    await RequestAsync("SetInputVolume",new {inputName=name,inputVolumeDb=Math.Clamp(db,-100,26)});
                    await RequestAsync("SetInputMute",new {inputName=name,inputMuted=m});
                }
                await SyncSourceFiltersAsync(name,c,state.TryGetProperty("fx",out var effects)?effects:default,n-1);
            }
        }
    }
    public Task RequestAsync(string type,object data)=>RequestAsync(type,data,Guid.NewGuid().ToString("N"));
    private Task RequestAsync(string type,object data,string id)=>SendAsync(new {op=6,d=new {requestType=type,requestId=id,requestData=data}});
    private async Task SendAsync(object value){if(socket is null)return;var bytes=JsonSerializer.SerializeToUtf8Bytes(value);await sendLock.WaitAsync();try{await socket.SendAsync(bytes,WebSocketMessageType.Text,true,CancellationToken.None);}finally{sendLock.Release();}}
    private async Task ReceiveLoopAsync()
    {
        var b=new byte[65536];
        while(socket?.State==WebSocketState.Open)
        {
            try
            {
                var r=await socket.ReceiveAsync(b,CancellationToken.None); if(r.MessageType==WebSocketMessageType.Close)break;
                using var d=JsonDocument.Parse(b.AsMemory(0,r.Count)); var root=d.RootElement;
                if(root.GetProperty("op").GetInt32()==7)
                {
                    var e=root.GetProperty("d"); var request=e.GetProperty("requestType").GetString();
                    if(e.TryGetProperty("requestStatus",out var rs)&&rs.TryGetProperty("result",out var ok)&&!ok.GetBoolean()) StatusChanged?.Invoke("OBS error: "+(rs.TryGetProperty("comment",out var comment)?comment.GetString():"request failed"),true);
                    if(request=="GetInputList"&&e.TryGetProperty("responseData",out var data))
                    {
                        var names=data.GetProperty("inputs").EnumerateArray().Select(x=>x.GetProperty("inputName").GetString()??"").Where(x=>x.Length>0).OrderBy(x=>x).ToArray();
                        InputsReceived?.Invoke(names);
                        foreach(var source in assigned.Values.Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct()) _=RequestFiltersAsync(source);
                    }
                    if(request=="GetSourceFilterList"&&pendingFilters.Remove(e.GetProperty("requestId").GetString()??"",out var sourceName)&&e.TryGetProperty("responseData",out var filterData))
                    {
                        knownFilters[sourceName]=filterData.GetProperty("filters").EnumerateArray().Select(x=>x.TryGetProperty("filterName",out var fn)?fn.GetString()??"":"").Where(x=>x.Length>0).ToHashSet();
                        lastFilterValues.Remove(sourceName);
                    }
                }
            }
            catch(Exception ex){connected=false;StatusChanged?.Invoke("OBS connection failed: "+ex.Message,false);break;}
        }
        if(connected){connected=false;StatusChanged?.Invoke("OBS disconnected",false);}
    }

    private async Task RequestFiltersAsync(string source)
    {
        if(!connected||string.IsNullOrWhiteSpace(source)||knownFilters.ContainsKey(source)||!requestedFilters.Add(source))return;
        var id="golive-filters-"+Guid.NewGuid().ToString("N");pendingFilters[id]=source;
        try{await RequestAsync("GetSourceFilterList",new{sourceName=source},id);}catch{requestedFilters.Remove(source);pendingFilters.Remove(id);}
    }

    private async Task SyncSourceFiltersAsync(string source,JsonElement channel,JsonElement effects,int channelIndex)
    {
        if(!knownFilters.TryGetValue(source,out var existing)){await RequestFiltersAsync(source);return;}
        if(!channel.TryGetProperty("dsp",out var dsp))return;
        var bypass=Bool(dsp,"bypass");var gateOn=Bool(dsp,"gOn")&&!bypass;var eqOn=Bool(dsp,"eOn")&&!bypass;var compOn=Bool(dsp,"cOn")&&!bypass;
        var g=ReadArray(dsp,"g",[-40,-47,12,300,300]);var c=ReadArray(dsp,"c",[-20,3,8,120,1]);
        var compressor=new {threshold=AtIndex(c,0,-20),ratio=AtIndex(c,1,3),attack_time=(int)AtIndex(c,2,8),release_time=(int)AtIndex(c,3,120),output_gain=AtIndex(c,4,1),sidechain_source="none"};
        var fxList=effects.ValueKind==JsonValueKind.Array?effects.EnumerateArray().ToArray():[];
        var effectActive=fxList.Any(x=>Bool(x,"on")&&AtBool(x,"asg",channelIndex)&&At(x,"snd",channelIndex,-60)>-59.9&&Num(x,"ret",-60)>-59.9);
        var fxChunk=MakeChunk(fxList,channelIndex,g,gateOn,ArrayElements(dsp,"e"),eqOn);
        var vstEnabled=gateOn||eqOn||effectActive;
        var vst=new {plugin_path=Path.Combine(AppContext.BaseDirectory,"Resources","GoLiveFX.dll"),chunk_data=Convert.ToBase64String(fxChunk),chunk_hash=""};
        var signature=JsonSerializer.Serialize(new{compressor,compOn,vst,vstEnabled,bypass});
        if(lastFilterValues.GetValueOrDefault(source)==signature)return;lastFilterValues[source]=signature;
        foreach(var old in new[]{"GoLive Input Trim","GoLive VST FX","GoLive EQ","GoLive Noise Gate","GoLive Gate","GoLive 3-Band EQ","GoLive Main Limiter","GoLive Parametric EQ","GoLive 6-Band Parametric EQ"})
            if(existing.Contains(old)){await RequestAsync("SetSourceFilterEnabled",new{sourceName=source,filterName=old,filterEnabled=false});}
        await UpsertFilter(source,"GoLive Compressor","compressor_filter",compressor,compOn,existing);
        if(vstEnabled||existing.Contains("GoLive FX"))await UpsertFilter(source,"GoLive FX","vst_filter",vst,vstEnabled&&!bypass,existing);
    }

    private async Task UpsertFilter(string source,string name,string kind,object settings,bool enabled,HashSet<string> existing)
    {
        if(!existing.Contains(name))
        {
            await RequestAsync("CreateSourceFilter",new{sourceName=source,filterName=name,filterKind=kind,filterSettings=settings});
            existing.Add(name);
        }
        await RequestAsync("SetSourceFilterSettings",new{sourceName=source,filterName=name,filterSettings=settings,overlay=true});
        await RequestAsync("SetSourceFilterEnabled",new{sourceName=source,filterName=name,filterEnabled=enabled});
    }

    private static byte[] MakeChunk(JsonElement[] fx,int channel,double[] gate,bool gateOn,JsonElement[] eq,bool eqOn)
    {
        var values=new float[72];var types=new[]{"","Hall Reverb","Room Reverb","Chamber Reverb","Plate Reverb","Stereo Delay","Stereo Chorus"};
        var ranges=new Dictionary<string,(double,double)[]>{
            ["Hall Reverb"]=[(0,200),(.2,5),(2,100),(1000,20000),(0,100),(20,400)],
            ["Room Reverb"]=[(0,200),(.2,5),(2,100),(1000,20000),(0,100),(20,400)],
            ["Chamber Reverb"]=[(0,200),(.2,5),(2,100),(1000,20000),(0,100),(20,400)],
            ["Plate Reverb"]=[(0,200),(.2,5),(2,100),(1000,20000),(-15,15),(20,400)],
            ["Stereo Delay"]=[(10,1000),(0,90),(20,400),(1000,20000)],
            ["Stereo Chorus"]=[(.05,10),(0,100),(1,40),(0,100)]};
        for(var slot=0;slot<4&&slot<fx.Length;slot++)
        {
            var e=fx[slot];var b=slot*10;var name=Str(e,"t","");var type=System.Array.IndexOf(types,name);var assigned=AtBool(e,"asg",channel);var send=assigned?At(e,"snd",channel,-60):-60;var ret=Num(e,"ret",-60);var p=ReadArray(e,"p",[]);
            values[b]=type<0?0:type/6f;values[b+1]=Bool(e,"on")&&assigned&&send>-59.9&&ret>-59.9?1:0;values[b+2]=Norm(send,-60,6);values[b+3]=Norm(ret,-60,6);
            if(ranges.TryGetValue(name,out var rs))for(var j=0;j<Math.Min(6,rs.Length);j++)values[b+4+j]=Norm(j<p.Length?p[j]:rs[j].Item1,rs[j].Item1,rs[j].Item2);
        }
        values[40]=gateOn?1:0;values[41]=Norm(gate.ElementAtOrDefault(0),-80,0);values[42]=Norm(gate.ElementAtOrDefault(1),-80,0);values[43]=Norm(gate.ElementAtOrDefault(2),1,200);values[44]=Norm(gate.ElementAtOrDefault(3),0,2000);values[45]=Norm(gate.ElementAtOrDefault(4),5,2000);values[46]=eqOn?1:0;
        var eqTypes=new Dictionary<string,int>{{"lc",0},{"lcut",0},{"ls",1},{"pk",2},{"vq",3},{"hs",4},{"hc",5}};
        for(var band=0;band<5;band++)
        {
            var b=47+band*5;var e=band<eq.Length?eq[band]:default;var kind=Str(e,"t","pk");var freq=Math.Clamp(Num(e,"f",1000),20,20000);var gain=Math.Clamp(Num(e,"gain",0)*1.5,-15,15);var q=Math.Clamp(Num(e,"q",.71),.3,8);var on=eqOn&&Bool(e,"on");
            values[b]=on?1:0;values[b+1]=(eqTypes.GetValueOrDefault(kind,2))/5f;values[b+2]=(float)(Math.Log(freq/20)/Math.Log(1000));values[b+3]=Norm(gain,-15,15);values[b+4]=Norm(q,.3,8);
        }
        var bytes=new byte[values.Length*sizeof(float)];Buffer.BlockCopy(values,0,bytes,0,bytes.Length);return bytes;
    }
    private static float Norm(double v,double lo,double hi)=>(float)Math.Clamp((v-lo)/(hi-lo),0,1);
    private static bool Bool(JsonElement e,string k)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.True;
    private static string Str(JsonElement e,string k,string d)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()??d:d;
    private static double Num(JsonElement e,string k,double d)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.TryGetDouble(out var n)?n:d;
    private static double At(JsonElement e,string k,int i,double d)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.Array&&v.GetArrayLength()>i&&v[i].TryGetDouble(out var n)?n:d;
    private static bool AtBool(JsonElement e,string k,int i)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.Array&&v.GetArrayLength()>i&&v[i].ValueKind==JsonValueKind.True;
    private static double[] ReadArray(JsonElement e,string k,double[] d)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.Array?v.EnumerateArray().Select(x=>x.TryGetDouble(out var n)?n:0).ToArray():d;
    private static double AtIndex(double[] values,int i,double d)=>values.Length>i?values[i]:d;
    private static JsonElement[] ArrayElements(JsonElement e,string k)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(k,out var v)&&v.ValueKind==JsonValueKind.Array?v.EnumerateArray().Select(x=>x.Clone()).ToArray():[];
}
