$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'GoLive.Windows.csproj'
$output = Join-Path $PSScriptRoot 'dist\win-x64'
dotnet publish $project -Configuration Release -RuntimeIdentifier win-x64 `
  --SelfContained true `
  -p:EnableWindowsTargeting=true `
  -p:PublishSingleFile=true `
  -p:IncludeNativeLibrariesForSelfExtract=true `
  -o $output
Write-Host "Windows build created at $output"
